# Delete All Channels Bot

/ delete で全チャンネル削除の確認メッセージとボタンを表示します。Flaskで/と/healthを公開します。Render向け。